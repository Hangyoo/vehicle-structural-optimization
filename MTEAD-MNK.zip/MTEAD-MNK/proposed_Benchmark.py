from jmetal.core.quality_indicator import HyperVolume, InvertedGenerationalDistance
from jmetal.operator import PolynomialMutation, DifferentialEvolutionCrossover
from jmetal.util.solution import get_non_dominated_solutions
from jmetal.util.termination_criterion import StoppingByEvaluations
from examples.MOMA_LD.util.func_tool import *
from algorithmCarShape.MTO_benchmark.cec2017 import *
import pickle

from algorithmCarShape.core.Proposed import ProposedAlgorithm

if __name__ == '__main__':
    # [[CIHS1, CIHS2],[CIMS1, CIMS2],[CILS1, CILS2],
    #  [PIHS1, PIHS2],[PIMS1, PIMS2],[PILS1, PILS2],
    #  [NIHS1, NIHS2],[NIMS1, NIMS2],[NILS1, NILS2]]

    problemset = [[CIHS1(convert=True), CIHS2(convert=True)], [CIMS1(convert=True), CIMS2(convert=True)],
                  [CILS1(convert=True), CILS2(convert=True)], [PIHS1(convert=True), PIHS2(convert=True)],
                  [PIMS1(convert=True), PIMS2(convert=True)], [PILS1(convert=True), PILS2(convert=True)],
                  [NIHS1(convert=True), NIHS2(convert=True)], [NIMS1(convert=True), NIMS2(convert=True)],
                  [NILS1(convert=True), NILS2(convert=True)]]

    # problemset = [[PILS1(convert=True),PILS2(convert=True)]]
    runTime = 31  # 独立运行次数
    popSize = 100
    iterNum = 500
    fileName = 'proposed_nd'

    for problems in problemset:
        metrics = np.zeros((runTime, 4))
        for i in range(runTime):
            print(f'第{i + 1}次运行:')

            algorithm = ProposedAlgorithm(
                problems=problems,
                population_size=popSize,
                crossover=DifferentialEvolutionCrossover(CR=0.9, F=0.5),
                mutation=PolynomialMutation(probability=1.0 / problems[0].number_of_variables, distribution_index=20),
                neighbor_size=10,
                max_number_of_replaced_solutions=popSize,
                beta=0.2,
                tr=0.5,
                weight_files_path=r'C:\Users\Hangyu\PycharmProjects\进化算法库\resources\MOEAD_weights',
                termination_criterion=StoppingByEvaluations(max_evaluations=2 * popSize * iterNum)
            )

            algorithm.run()
            fronts = algorithm.get_result()

            for j in range(len(fronts)):
                front = get_non_dominated_solutions(fronts[j])  # 非支配排序
                front = check(front)
                print_function_values_to_file(front, f'./results/{fileName}/{problems[j].get_name()}_FUN_{algorithm.get_name()}_T{j + 1}_{i}')
                print_variables_to_file(front, f'./results/{fileName}/{problems[j].get_name()}_VAR_{algorithm.get_name()}_T{j + 1}_{i}')
                print(f'Task{j+1}获得Pareto前沿解的数目为:', len(front), "个")

                # Calculate performance metrics
                igd = InvertedGenerationalDistance(problems[j].front) # 实际问题暂无真实前沿
                hypervolume = HyperVolume([1.0] * problems[j].number_of_objectives)
                igdVal = igd.compute([front[j].objectives for j in range(len(front))])
                hvVal = hypervolume.compute([front[j].objectives for j in range(len(front))])
                metrics[i, 0 + 2 * j] = igdVal
                metrics[i, 1 + 2 * j] = hvVal
                print("IGD: " + str(igdVal))
                print(f"Hypervolume {problems[0].get_name()}T{j+1}: " + str())

            print(f'Algorithm: ${algorithm.get_name()}')
            print(f'Problem: ${problems[0].get_name()}')
            print(f'Computing time: ${algorithm.total_computing_time}')

            # Save igd and hv trace to pickle
            with open(rf'./results/{fileName}/trace/{problems[0].get_name()}_trace_igd_{i}.pkl', 'wb') as f:
                pickle.dump(algorithm.trace['IGD'], f)

            with open(rf'./results/{fileName}/trace/{problems[0].get_name()}_trace_hv_{i}.pkl', 'wb') as f:
                pickle.dump(algorithm.trace['HV'], f)

        # Save igd and hv metrics to excel
        metrics = pd.DataFrame(metrics, columns=['IGDT1', 'HVT1', 'IGDT2', 'HVT2'])
        metrics.to_excel(rf'./results/{fileName}/metrics/{problems[0].get_name()}_metric.xlsx', index=False)