import copy
import random
import time
import logging
from typing import TypeVar, List, Generator
import numpy as np
import sys

from jmetal.algorithm.singleobjective.genetic_algorithm import GeneticAlgorithm
from jmetal.config import store
from jmetal.core.operator import Mutation, Crossover
from jmetal.core.problem import Problem
from jmetal.operator import DifferentialEvolutionCrossover, NaryRandomSolutionSelection
from jmetal.util.density_estimator import CrowdingDistance
from jmetal.util.evaluator import Evaluator
from jmetal.util.uniformpoint import uniformpoint
from jmetal.util.neighborhood import WeightVectorNeighborhood
from jmetal.util.ranking import FastNonDominatedRanking
from jmetal.util.termination_criterion import TerminationCriterion, StoppingByEvaluations
from jmetal.util.replacement import RankingAndDensityEstimatorReplacement, RemovalPolicyType
from jmetal.operator import PolynomialMutation, MOEAD_M2M_Crossover, MOEAD_M2M_Mutation
from jmetal.util.comparator import DominanceComparator
from jmetal.core.quality_indicator import HyperVolume, InvertedGenerationalDistance

from jmetal.util.point import IdealPoint, NadirPoint
from algorithmCarShape.algorithms.GreyRelationAnalysis import GreyRelationAnalysis

LOGGER = logging.getLogger('jmetal')
S = TypeVar('S')
R = List[S]


class MTEADDN(GeneticAlgorithm):
    def __init__(self,
                 problems,
                 population_size: int,
                 mutation: Mutation,
                 crossover,
                 max_number_of_replaced_solutions: int,
                 neighbor_size: int,
                 weight_files_path: str,
                 termination_criterion: TerminationCriterion = store.default_termination_criteria,
                 population_generator: Generator = store.default_generator,
                 population_evaluator: Evaluator = store.default_evaluator):

        # 基类GeneticAlgorithm的构造函数
        super().__init__(
            problem=problems,
            population_size=population_size,
            offspring_population_size=1,
            mutation=mutation,
            crossover=crossover,
            selection=NaryRandomSolutionSelection(2),  # 随机选择两个
            population_evaluator=population_evaluator,
            population_generator=population_generator,
            termination_criterion=termination_criterion
        )
        self.problems = problems
        self.max_number_of_replaced_solutions = max_number_of_replaced_solutions
        self.neighbourhood1 = WeightVectorNeighborhood(
            number_of_weight_vectors=population_size,
            neighborhood_size=neighbor_size,
            weight_vector_size=problems[0].number_of_objectives,
            weights_path=weight_files_path)
        self.neighbourhood2 = WeightVectorNeighborhood(
            number_of_weight_vectors=population_size,
            neighborhood_size=neighbor_size,
            weight_vector_size=problems[0].number_of_objectives,
            weights_path=weight_files_path)
        self.neighbourhoods = [self.neighbourhood1, self.neighbourhood2]  # 初始化邻域
        self.secondNeighbor = [self.initSecondNeighbor(self.neighbourhood2),  # 1的第二邻域对应0
                               self.initSecondNeighbor(self.neighbourhood1)]  # 0的第二邻域对应1

        self.permutations = None
        self.current_subproblem = 0
        self.neighbor_type = None  # 字符串类型，'NEIGHBOR_1', 'NEIGHBOR_2' 或 ‘POPULATION’
        self.counter = 0  # 用于记录迭代次数gen

        self.beta1 = 0.2
        self.beta2 = 0.5
        self.gra = GreyRelationAnalysis()
        self.trace = {'IGD': [[], []], "HV": [[], []]}

    def initSecondNeighbor(self, neighbourhood):
        # 任务为源任务, 第二种群(外部种群)对应的是目标任务
        secondNeighborhood = copy.deepcopy(neighbourhood)
        seconNeighbor = []
        for j in range(self.population_size):
            index = random.randint(0, self.population_size - 1)
            seconNeighbor.append(neighbourhood.get_neighborhood()[index])  # 返回索引，不是个体
        secondNeighborhood.neighborhood = np.array(seconNeighbor)
        return secondNeighborhood

    """
    算法的流程框架
    self.solutions = self.create_initial_solutions()
    self.solutions = self.evaluate(self.solutions)
    self.init_progress()
    while not self.stopping_condition_is_met():
        self.step()
        self.update_progress()
    """

    def create_initial_solutions(self) -> List[S]:
        populations = []
        for i in range(self.problems[0].getNumberOfTasks()):
            number_of_variables = self.problems[i].number_of_variables
            population = [self.population_generator.new(self.problems[i]) for _ in range(self.population_size)]
            for j in range(self.population_size):
                population[j].variables = [random.uniform(0.0, 1.0) for _ in range(number_of_variables)]
                population[j].skill_factor = i  # 为每个解设置所属任务

            populations.append(population)
        return populations

    def initIdealPoint(self):
        # 初始化
        self.idealPoints = []
        for i in range(self.problems[0].getNumberOfTasks()):
            self.idealPoints.append(IdealPoint(self.problems[i].number_of_objectives))
        # 在每个种群(任务)上进行更新
        for i in range(self.problems[0].getNumberOfTasks()):
            for j in range(self.population_size):
                self.idealPoints[i].update(self.solutions[i][j].objectives)

    def initNadirPoint(self):
        # 初始化
        self.nadirPoints = []
        for i in range(self.problems[0].getNumberOfTasks()):
            self.nadirPoints.append(NadirPoint(self.problems[i].number_of_objectives))
        # 在每个种群(任务)上进行更新
        for i in range(self.problems[0].getNumberOfTasks()):
            for j in range(self.population_size):
                self.nadirPoints[i].update(self.solutions[i][j].objectives)

    def init_progress(self) -> None:
        self.initIdealPoint()  # 初始化理想点
        self.initNadirPoint()  # 初始化天底点
        self.evaluations = self.population_size + self.population_size
        self.permutations = [Permutation(self.population_size), Permutation(self.population_size)] # 打乱序号
        observable_data = self.get_observable_data()
        self.observable.notify_all(**observable_data)

    def step(self):
        for task_idx in range(self.problems[0].getNumberOfTasks()):
            mating_population = self.selection(self.solutions, task_idx)
            offspring_population = self.reproduction(mating_population, task_idx)
            offspring_population = self.evaluate(offspring_population, task_idx)
            self.replacement(self.solutions, offspring_population, task_idx)  # 返回了下一代种群

    def choose_neighbor_type(self):
        if random.random() < self.beta1:
            if random.random() < self.beta2:
                return 'NEIGHBOR_1'
            else:
                return 'NEIGHBOR_2'
        else:
            return 'POPULATION'

    def selection(self, population: List[S], src_task):
        # 获取第i个子问题，get_next_value()后，指针会自动向后移动
        # counter == 0, 迭代次数就多一次; counter记录当前第几个数
        self.current_subproblem, self.counter = self.permutations[src_task].get_next_value()
        sp = self.current_subproblem
        # neighbour selection
        self.neighbor_type = self.choose_neighbor_type()

        # parent selection
        if self.neighbor_type == 'POPULATION':
            # Mating pool 从整个种群中随机选择两个
            mating_population = self.selection_operator.execute(population[src_task])
        else:
            # 获取当前问题的邻域
            tar_task = self.random_task(src_task)
            innerNeighbors = self.neighbourhoods[src_task].get_neighbors(sp, self.solutions[src_task])  # neighborhoods中srcTask任务的sp的邻域加入mating pool
            outerNeighbors = self.secondNeighbor[src_task].get_neighbors(sp, self.solutions[tar_task])  # secondneighbor中srcTask任务的sp的邻域加入mating pool
            mating_population = self.selection_operator.execute(innerNeighbors + outerNeighbors)

        # 将当前解加入列表
        mating_population.append(population[src_task][sp])
        return mating_population

    def chooseTask(self, src_task):
        if self.neighbor_type == "NEIGHBOR_2": # 返回另一个任务
            tarTask = random.randint(0, self.problems[0].getNumberOfTasks() - 1)
            while tarTask == src_task:
                tarTask = random.randint(0, self.problems[0].getNumberOfTasks() - 1)
            return tarTask

        return src_task # 返回当前任务

    def random_task(self, nfes):  # 生成一个不等于nfes的task索引 随机返回[0,1]中的一个数
        task = random.randint(0, self.problems[0].getNumberOfTasks() - 1)
        while task == nfes:
            task = random.randint(0, self.problems[0].getNumberOfTasks() - 1)
        return task

    def reproduction(self, mating_population: List[S], src_task) -> List[S]:
        '''交叉变异操作  返回后代个体，offspring_population'''
        # 将当前子问题对应的解赋给 self.crossover_operator.current_individual
        self.crossover_operator.current_individual = self.solutions[src_task][self.current_subproblem]
        offspring_population = self.crossover_operator.execute(mating_population)  # 返回交叉产生的新个体 child
        self.mutation_operator.execute(offspring_population[0])  # 返回变异产生的新个体
        tarTask = self.chooseTask(src_task)
        if tarTask != src_task:
            # print(f"{src_task} to {tarTask} 目标变了")
            # print(f'before:{len(offspring_population[0].objectives)}',offspring_population[0].objectives)
            offspring_population[0].objectives = self.solutions[tarTask][0].objectives
            # print(f'after:{len(offspring_population[0].objectives)}',offspring_population[0].objectives)
        offspring_population[0].skill_factor = tarTask



        return offspring_population

    def evaluate(self, population: List[S], src_task=None):
        # todo 映射回原始空间
        if src_task != None:
            # origin_x = self.transform(population[0])
            self.population_evaluator.evaluate(population, self.problems[population[0].skill_factor])
            # population[0].variables = origin_x
        else:
            for i in range(self.problems[0].getNumberOfTasks()):
                self.population_evaluator.evaluate(population[i], self.problems[i])
        return population

    def replacement(self, population: List[S], offspring_population: List[S], src_task):
        # 更新理想点
        src_task = offspring_population[0].skill_factor
        self.idealPoints[src_task].update(offspring_population[0].objectives)
        # print(f"更新T{src_task}理想点:{self.idealPoints[src_task].get_point()}")

        # 更新邻域解 (用reproduction（交叉变异）产生的个体替换 population 从而产生 offspring_population)
        self.updateNeighborhood(offspring_population[0], src_task, self.current_subproblem)


    def mean(self, neighbors):  # [sol1, sol2, ..., sol10]
        values = [0.0] * len(neighbors[0].variables)  # 长度为决策变量个数(50)
        for i in range(len(values)):
            for j in range(len(neighbors)):
                values[i] += neighbors[j].variables[i] / len(neighbors)
        return values

    def finder(self, updated, src_task, tar_task, sp):  # 更新替换的子问题索引列表[14,16,13,..10]、源任务、目标任务、子问题索引
        x0 = self.mean(self.neighbourhoods[src_task].get_neighbors(sp, self.solutions[src_task]))  # 源任务srcTask在sp子问题上的邻域均值
        x = [self.mean(self.neighbourhoods[tar_task].get_neighbors(updated[i], self.solutions[tar_task])) for i in range(len(updated))]
        index = updated[self.gra.execute(x0, x)]  # 从updated中选择最相关的索引
        return index

    def updateNeighborhood(self, child, src_task, sp):
        tar_task = child.skill_factor  # 获取当前个体属于哪个任务
        if tar_task == -1:
            raise Exception("skill_factor == -1")

        if tar_task == src_task:  # 目标任务 == 源任务 (邻域为type1 或 type3)
            if self.neighbor_type == "POPULATION":  # type3
                permuted_array = list(range(self.population_size))
                random.shuffle(permuted_array)
                self.update(child, src_task, permuted_array)  # 对整个种群进行替换
            else:  # type1
                permuted_array = copy.deepcopy(self.neighbourhoods[src_task].get_neighborhood()[sp].tolist())
                self.update(child, src_task, permuted_array)  # 对src_task的sp邻域进行替换
        else:  # 目标任务 != 源任务  type2
            if tar_task != self.secondNeighbor[src_task].get_neighbors(sp, self.solutions[tar_task])[0].skill_factor:
                raise Exception("if (tarTask != secondNeighbor.get(task).get(sp).getTask())")
            permuted_array = copy.deepcopy(self.secondNeighbor[src_task].get_neighborhood()[sp].tolist())
            updated = self.update(child, tar_task, permuted_array)  # 记录更新子问题sp的哪些邻域

            # update second neighborhood
            if len(updated) == 0:  # 没有更新任何一个，任意返回一个不等于当前任务的任务,令updated=[0,1,2,,99]
                tar_task = self.random_task(src_task)
                updated = list(range(self.population_size))  # 假设population_size是种群大小

            if len(updated) == 1:  # 更新second_neighbor
                self.secondNeighbor[src_task].neighborhood[sp] = self.neighbourhoods[tar_task].neighborhood[updated[0]]
                return None

            # 选择最相关的index来更新second_neighbor
            index = self.finder(updated, src_task, tar_task, sp)
            self.secondNeighbor[src_task].neighborhood[sp] = self.neighbourhoods[tar_task].neighborhood[index]

        return None

    def update(self, new_solution, task, ind):  # (x, 任务, 邻域个体索引)
        updated = []  # 更新过的索引
        replacements = 0
        for n in ind:  # 邻域 for n in [28,29,27,30,26,25,31,24,32,33]
            # 邻域内每个解的聚合函数值
            f1 = self.fitness(self.solutions[task][n].objectives, self.neighbourhoods[task].weight_vectors[n], task)
            f2 = self.fitness(new_solution.objectives, self.neighbourhoods[task].weight_vectors[n], task)
            if f2 < f1:
                self.solutions[task][n] = copy.deepcopy(new_solution)
                replacements += 1
                updated.append(n)
            # 判断最大替换次数
            if replacements >= self.max_number_of_replaced_solutions:
                break
        return updated

    def fitness(self, objectives, weight_vector, task):
        max_fun = -1.0e+30
        E = 1.0e-5
        for i in range(len(objectives)):  # 目标函数的个数
            diff = abs(objectives[i] - self.idealPoints[task].get_point()[i] + E)
            if weight_vector[i] == 0:
                feval = diff / 0.000001
            else:
                feval = diff / weight_vector[i]
            # 选取m个目标中 与权重向量乘积的最大值
            if feval > max_fun:
                max_fun = feval
        return max_fun


    def update_progress(self):
        '''写每一次迭代需要做的事情'''
        if self.evaluations % 10000 == 0:
            from jmetal.util.solution import get_non_dominated_solutions
            from examples.MOMA_LD.util.func_tool import check
            print(f'当前评估次数{self.evaluations}次', end=', ')
            for i in range(self.problems[0].getNumberOfTasks()):  # 记录IGD和HV指标收敛曲线
                result = get_non_dominated_solutions(self.solutions[i])
                front = check(result)
                igd = InvertedGenerationalDistance(self.problems[i].front)
                igdVal = round(igd.compute([front[j].objectives for j in range(len(front))]), 6)
                hypervolume = HyperVolume([1.0] * self.problems[i].number_of_objectives)
                hvVal = round(hypervolume.compute([front[j].objectives for j in range(len(front))]), 6)
                print(f"IGD_Task{i + 1}: " + str(igdVal), end=', ')
                print(f"HV_Task{i + 1}: " + str(hvVal), end=', ')
                self.trace['IGD'][i].append(igdVal)
                self.trace['HV'][i].append(hvVal)
            print()

        self.evaluations += (2 * self.offspring_population_size)

        # 更新当前的记录
        observable_data = self.get_observable_data()
        self.observable.notify_all(**observable_data)

    def get_name(self):
        return 'MTEAD-DN'

    def get_result(self):
        return self.solutions

    @property
    def label(self) -> str:
        return f'{self.get_name()}.{self.problems[0].get_name()}'


# 对0 ~ length-1 之间的数进行随机排列; 返回子问题的索引值
class Permutation:

    def __init__(self, length: int):
        self.counter = 0
        self.length = length
        self.permutation = np.random.permutation(length)

    def get_next_value(self):
        next_value = self.permutation[self.counter]
        self.counter += 1

        # 指向最后面时，重新生成一个排列，并将索引设置为0
        if self.counter == self.length:
            self.permutation = np.random.permutation(self.length)
            self.counter = 0

        return next_value, self.counter

    def get_permutation(self):
        return self.permutation.tolist()



