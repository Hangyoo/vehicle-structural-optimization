# -*- ecoding: utf-8 -*-
# @Project :  paper5
# @Author: Hangyu Lou
# @Time: 2024/4/16 15:35

import copy
import random
import time
import logging
from typing import TypeVar, List, Generator
import numpy as np
import sys

from jmetal.algorithm.singleobjective.genetic_algorithm import GeneticAlgorithm
from jmetal.config import store
from jmetal.core.operator import Mutation, Crossover
from jmetal.core.problem import Problem
from jmetal.operator import DifferentialEvolutionCrossover, NaryRandomSolutionSelection
from jmetal.util.density_estimator import CrowdingDistance
from jmetal.util.evaluator import Evaluator
from jmetal.util.uniformpoint import uniformpoint
from jmetal.util.neighborhood import WeightVectorNeighborhood
from jmetal.util.ranking import FastNonDominatedRanking
from jmetal.util.termination_criterion import TerminationCriterion, StoppingByEvaluations
from jmetal.util.replacement import RankingAndDensityEstimatorReplacement, RemovalPolicyType
from jmetal.operator import PolynomialMutation, MOEAD_M2M_Crossover, MOEAD_M2M_Mutation
from jmetal.util.comparator import DominanceComparator
from jmetal.core.quality_indicator import HyperVolume, InvertedGenerationalDistance

from jmetal.util.point import IdealPoint, NadirPoint
from algorithmCarShape.algorithms.GreyRelationAnalysis import GreyRelationAnalysis
from algorithmCarShape.core.MTEADDN import MTEADDN, Permutation

from jmetal.util.solution import get_non_dominated_solutions
from examples.MOMA_LD.util.func_tool import check

LOGGER = logging.getLogger('jmetal')
S = TypeVar('S')
R = List[S]


class ProposedAlgorithm(MTEADDN):
    def __init__(self,
                 problems,
                 population_size: int,
                 mutation: Mutation,
                 crossover,
                 max_number_of_replaced_solutions: int,
                 neighbor_size: int,
                 beta: float,
                 tr: float,
                 weight_files_path: str,
                 termination_criterion: TerminationCriterion = store.default_termination_criteria,
                 population_generator: Generator = store.default_generator,
                 population_evaluator: Evaluator = store.default_evaluator):

        # 基类GeneticAlgorithm的构造函数
        super().__init__(
            problems=problems,
            population_size=population_size,
            mutation=mutation,
            crossover=crossover,
            max_number_of_replaced_solutions = max_number_of_replaced_solutions,
            neighbor_size=neighbor_size,  # 随机选择两个
            weight_files_path = weight_files_path,
            population_evaluator=population_evaluator,
            population_generator=population_generator,
            termination_criterion=termination_criterion
        )
        self.problems = problems
        self.max_number_of_replaced_solutions = max_number_of_replaced_solutions
        self.neighbourhood1 = WeightVectorNeighborhood(
            number_of_weight_vectors=population_size,
            neighborhood_size=neighbor_size,
            weight_vector_size=problems[0].number_of_objectives,
            weights_path=weight_files_path)
        self.neighbourhood2 = WeightVectorNeighborhood(
            number_of_weight_vectors=population_size,
            neighborhood_size=neighbor_size,
            weight_vector_size=problems[1].number_of_objectives,
            weights_path=weight_files_path)
        self.neighbourhoods = [self.neighbourhood1, self.neighbourhood2]  # 初始化邻域
        self.secondNeighbor = [self.initSecondNeighbor(self.neighbourhood2),  # 1的第二邻域对应0
                               self.initSecondNeighbor(self.neighbourhood1)]  # 0的第二邻域对应1

        self.permutations = None
        self.current_subproblem = 0
        self.neighbor_type = None  # 字符串类型，'NEIGHBOR_1', 'NEIGHBOR_2_OBJ', 'NEIGHBOR_2_DEC' 或 ‘POPULATION’
        self.counter = 0  # 用于记录迭代次数gen


        self.gra = GreyRelationAnalysis()
        self.trace = {'IGD': [[], []], "HV": [[], []]}
        self.trace_flag = False

        self.model = [{'mean':[], 'std':[]} for _ in range(self.problems[0].getNumberOfTasks())] # 存储模型信息
        self.alpha = 0.5 # 不同种群进化方向中的参数

        self.tau2 = 0.1  # kp重置概率

        self.metric_save_times = 25 # 性能指标记录次数
        self.beta1 = beta # 0.2  邻域选择概率(种群0.2 or 邻域0.8)
        self.tr = tr      # 0.5 迁移概率
        self.generation = 0 # 当前迭代次数

    def initSecondNeighbor(self, neighbourhood):
        # 任务为源任务, 第二种群(外部种群)对应的是目标任务
        secondNeighborhood = copy.deepcopy(neighbourhood)
        seconNeighbor = []
        for j in range(self.population_size):
            index = random.randint(0, self.population_size - 1)
            seconNeighbor.append(neighbourhood.get_neighborhood()[index])  # 返回索引，不是个体
        secondNeighborhood.neighborhood = np.array(seconNeighbor)
        return secondNeighborhood

    """
    算法的流程框架
    self.solutions = self.create_initial_solutions()
    self.solutions = self.evaluate(self.solutions)
    self.init_progress()
    while not self.stopping_condition_is_met():
        self.step()
        self.update_progress()
    """

    def create_initial_solutions(self) -> List[S]:
        populations = []
        for i in range(self.problems[0].getNumberOfTasks()):
            number_of_variables = self.problems[i].number_of_variables
            population = [self.population_generator.new(self.problems[i]) for _ in range(self.population_size)]
            for j in range(self.population_size):
                population[j].variables = [random.uniform(0.0, 1.0) for _ in range(number_of_variables)]
                population[j].skill_factor = i  # 为每个解设置所属任务
                population[j].kt = np.random.rand()  # 目标空间和决策空间的选择(知识类型的选择)
                population[j].tr = self.tr #np.random.rand()  # 个体的迁移概率
                population[j].F = 0.5 # np.random.rand()
                population[j].CR = 0.9 # np.random.rand()
            populations.append(population)
        return populations

    def population_gaussian_distribution(self):
        for task_idx in range(self.problems[0].getNumberOfTasks()):
            variables = np.array([ind.variables for ind in self.solutions[task_idx]])
            self.model[task_idx]['mean'] = np.mean(variables,axis=0)
            self.model[task_idx]['std'] = np.std(variables,axis=0) + 1e-100
        return None

    def updata_model_values(self): # 更新种群信息(没迭代一次更新一回)
        for task_idx in range(self.problems[0].getNumberOfTasks()):
            variables = np.array([ind.variables for ind in self.solutions[task_idx]])
            self.model[task_idx]['mean'] = self.alpha * self.model[task_idx]['mean'] + (1 - self.alpha) * np.mean(variables,axis=0)
            self.model[task_idx]['std'] = self.alpha * self.model[task_idx]['std'] + (1 - self.alpha) * np.std(variables,axis=0) + 1e-100
        return None

    def product_y_based_descison_sapce(self, solution,task):
        y = copy.deepcopy(solution)
        variables = np.array(y.variables)
        xDeck = (variables - self.model[task]['mean']) / self.model[task]['std']
        y.variables = self.model[task]['mean'] + self.model[task]['std'] * xDeck
        return y

    def init_progress(self) -> None:
        self.initIdealPoint()  # 初始化理想点
        self.initNadirPoint()  # 初始化天底点
        self.population_gaussian_distribution() # 统计模型信息
        self.evaluations = self.population_size + self.population_size
        self.permutations = [Permutation(self.population_size), Permutation(self.population_size)] # 打乱序号
        self.lastSolutions = copy.deepcopy(self.solutions) # 记录当前种群, 用于计算ASF提升量,以更新kt
        observable_data = self.get_observable_data()
        self.observable.notify_all(**observable_data)

    def step(self):
        for task_idx in range(self.problems[0].getNumberOfTasks()):
            mating_population = self.selection(self.solutions, task_idx)
            offspring_population = self.reproduction(mating_population, task_idx)
            offspring_population = self.evaluate(offspring_population, task_idx)
            self.replacement(self.solutions, offspring_population, task_idx)  # 返回了下一代种群

    def choose_neighbor_type(self, solution):
        if random.random() < self.beta1:
            # if random.random() < self.beta2:
            if random.random() < solution.tr: # 是否迁移
                return 'NEIGHBOR_1'
            else:
                # return 'NEIGHBOR_2_DEC'  # 此时没有双邻域
                if random.random() < solution.kt: # 在目标空间 or 决策空间
                    return 'NEIGHBOR_2_OBJ'    # 利用目标空间信息指导迁移学习
                else:
                    a = 0
                    return 'NEIGHBOR_2_DEC' # 利用决策空间信息指导迁移学习
        else:
            return 'POPULATION'

    def selection(self, population: List[S], src_task):
        # 获取第i个子问题，get_next_value()后，指针会自动向后移动
        # counter == 0, 迭代次数就多一次; counter记录当前第几个数
        self.current_subproblem, self.counter = self.permutations[src_task].get_next_value()
        sp = self.current_subproblem
        # neighbour selection
        self.neighbor_type = self.choose_neighbor_type(population[src_task][sp]) # 根据当前解的kt来确定是否要迁移

        # parent selection
        if self.neighbor_type == 'POPULATION':
            # Mating pool 从整个种群中随机选择两个
            mating_population = self.selection_operator.execute(population[src_task])
            mating_population.append(population[src_task][sp])
        elif self.neighbor_type == 'NEIGHBOR_1' or self.neighbor_type == 'NEIGHBOR_2_OBJ':
            # 知识类型1：根据目标空间产生后代
            tar_task = self.random_task(src_task)
            innerNeighbors = self.neighbourhoods[src_task].get_neighbors(sp, self.solutions[src_task])  # neighborhoods中srcTask任务的sp的邻域加入mating pool
            outerNeighbors = self.secondNeighbor[src_task].get_neighbors(sp, self.solutions[tar_task])  # secondneighbor中srcTask任务的sp的邻域加入mating pool
            mating_population = self.selection_operator.execute(innerNeighbors + outerNeighbors)
            mating_population.append(population[src_task][sp])
        elif self.neighbor_type == 'NEIGHBOR_2_DEC':
            # 知识类型2：根据决策空间产生后代(利用另一个任务的进化信息来指导当前信息)
            tar_task = self.random_task(src_task)
            random_idx = random.randint(0,self.population_size-1)
            # todo 1 采用 srctask,tartask 还是 tartask,srctask (下面两行的任务不能一样)
            y = self.product_y_based_descison_sapce(population[tar_task][random_idx], tar_task) # 利用tar_task种群的进化信息指导src_task
            mating_population = self.selection_operator.execute(population[src_task])
            mating_population.append(y)
        else:
            raise Exception("neighbor_type != POPULATION, NEIGHBOR_1, NEIGHBOR_2_OBJ and NEIGHBOR_2_DEC")
        # 将当前解加入列表
        return mating_population

    def chooseTask(self, src_task):
        if self.neighbor_type == "NEIGHBOR_2_OBJ" or self.neighbor_type == "NEIGHBOR_2_DEC": # 返回另一个任务
            tarTask = random.randint(0, self.problems[0].getNumberOfTasks() - 1)
            while tarTask == src_task:
                tarTask = random.randint(0, self.problems[0].getNumberOfTasks() - 1)
            return tarTask
        return src_task # 返回当前任务

    def random_task(self, nfes):  # 生成一个不等于nfes的task索引 随机返回[0,1]中的一个数
        task = random.randint(0, self.problems[0].getNumberOfTasks() - 1)
        while task == nfes:
            task = random.randint(0, self.problems[0].getNumberOfTasks() - 1)
        return task

    def binomial_crossover(self,offspring,parent,CR):
        length = len(offspring.variables)
        for i in range(length):
            if random.random() > CR:
                if random.randint(0,length-1) == i: # 不换
                    pass
                else:
                    offspring.variables[i] = parent.variables[i]

        # 变量越界修复
        for i in range(length):
            if offspring.variables[i] < 0:
                offspring.variables[i] = 0
            if offspring.variables[i] > 1:
                offspring.variables[i] = 1

        return [offspring]

    def reproduction(self, mating_population: List[S], src_task) -> List[S]:
        '''交叉变异操作  返回后代个体，offspring_population'''
        # 知识类型1：根据目标空间产生后代
        if self.neighbor_type in ['POPULATION','NEIGHBOR_1','NEIGHBOR_2_OBJ']:
            self.crossover_operator.current_individual = self.solutions[src_task][self.current_subproblem]
            offspring_population = self.crossover_operator.execute(mating_population)  # 返回交叉产生的新个体 child
            self.mutation_operator.execute(offspring_population[0])  # 返回变异产生的新个体

        # 知识类型2：根据决策空间产生后代(与MKTA论文中一致,采用差分变异,多项式交叉算子)
        else:
            offspring = copy.deepcopy(self.solutions[src_task][self.current_subproblem])
            parent = self.solutions[src_task][self.current_subproblem]

            random_idx = random.sample(range(self.population_size - 1), k=2)
            x1 = self.solutions[src_task][random_idx[0]].variables # x1
            x3 = self.solutions[src_task][random_idx[0]].variables # x3
            y = mating_population[-1].variables # x2
            # Differential Mutation
            offspring.variables = x1 + (0.2+random.random()) * (y - x3)
            # Binomial crossover
            offspring_population = self.binomial_crossover(offspring,parent,parent.CR)

        tarTask = self.chooseTask(src_task)
        if tarTask != src_task:
            offspring_population[0].objectives = self.solutions[tarTask][0].objectives
        offspring_population[0].skill_factor = tarTask

        return offspring_population

    def evaluate(self, population: List[S], src_task=None):
        if src_task != None:
            self.population_evaluator.evaluate(population, self.problems[population[0].skill_factor])
        else:
            for i in range(self.problems[0].getNumberOfTasks()):
                self.population_evaluator.evaluate(population[i], self.problems[i])
        return population

    def replacement(self, population: List[S], offspring_population: List[S], src_task):
        # 更新理想点
        src_task = offspring_population[0].skill_factor
        self.idealPoints[src_task].update(offspring_population[0].objectives)
        # print(f"更新T{src_task}理想点:{self.idealPoints[src_task].get_point()}")

        # 更新邻域解 (用reproduction（交叉变异）产生的个体替换 population 从而产生 offspring_population)
        self.updateNeighborhood(offspring_population[0], src_task, self.current_subproblem)


    def mean(self, neighbors):  # [sol1, sol2, ..., sol10]
        values = [0.0] * len(neighbors[0].variables)  # 长度为决策变量个数(50)
        for i in range(len(values)):
            for j in range(len(neighbors)):
                values[i] += neighbors[j].variables[i] / len(neighbors)
        return values

    def finder(self, updated, src_task, tar_task, sp):  # 更新替换的子问题索引列表[14,16,13,..10]、源任务、目标任务、子问题索引
        x0 = self.mean(self.neighbourhoods[src_task].get_neighbors(sp, self.solutions[src_task]))  # 源任务srcTask在sp子问题上的邻域均值
        x = [self.mean(self.neighbourhoods[tar_task].get_neighbors(updated[i], self.solutions[tar_task])) for i in range(len(updated))]
        index = updated[self.gra.execute(x0, x)]  # 从updated中选择最相关的索引
        return index

    def updateNeighborhood(self, child, src_task, sp):
        tar_task = child.skill_factor  # 获取当前个体属于哪个任务
        if tar_task == -1:
            raise Exception("skill_factor == -1")

        if tar_task == src_task:  # 目标任务 == 源任务 (邻域为type1 或 type3)
            if self.neighbor_type == "POPULATION":  # type3
                permuted_array = list(range(self.population_size))
                random.shuffle(permuted_array)
                self.update(child, src_task, permuted_array)  # 对整个种群进行替换
            else:  # type1
                permuted_array = copy.deepcopy(self.neighbourhoods[src_task].get_neighborhood()[sp].tolist())
                self.update(child, src_task, permuted_array)  # 对src_task的sp邻域进行替换
        elif self.neighbor_type == 'NEIGHBOR_2_OBJ':  # 目标任务 != 源任务  type2
            if tar_task != self.secondNeighbor[src_task].get_neighbors(sp, self.solutions[tar_task])[0].skill_factor:
                raise Exception("if (tarTask != secondNeighbor.get(task).get(sp).getTask())")
            permuted_array = copy.deepcopy(self.secondNeighbor[src_task].get_neighborhood()[sp].tolist())
            updated = self.update(child, tar_task, permuted_array)  # 记录更新子问题sp的哪些邻域

            # update second neighborhood
            if len(updated) == 0:  # 没有更新任何一个，任意返回一个不等于当前任务的任务,令updated=[0,1,2,,99]
                tar_task = self.random_task(src_task)
                updated = list(range(self.population_size))  # 假设population_size是种群大小

            if len(updated) == 1:  # 更新second_neighbor
                self.secondNeighbor[src_task].neighborhood[sp] = self.neighbourhoods[tar_task].neighborhood[updated[0]]
                return None

            # 选择最相关的index来更新second_neighbor
            index = self.finder(updated, src_task, tar_task, sp)
            self.secondNeighbor[src_task].neighborhood[sp] = self.neighbourhoods[tar_task].neighborhood[index]
        elif self.neighbor_type == 'NEIGHBOR_2_DEC': # 'NEIGHBOR_2_DEC'
            permuted_array = copy.deepcopy(self.neighbourhoods[src_task].get_neighborhood()[sp].tolist())
            self.update(child, src_task, permuted_array)  # 对src_task的sp邻域进行替换
        else:
            raise Exception("neighbor_type != POPULATION, NEIGHBOR_1, NEIGHBOR_2_OBJ and NEIGHBOR_2_DEC")
        return None

    def update(self, new_solution, task, ind):  # (x, 任务, 邻域个体索引)
        updated = []  # 更新过的索引
        replacements = 0
        for n in ind:  # 邻域 for n in [28,29,27,30,26,25,31,24,32,33]
            # 邻域内每个解的聚合函数值
            f1 = self.fitness(self.solutions[task][n].objectives, self.neighbourhoods[task].weight_vectors[n], task)
            f2 = self.fitness(new_solution.objectives, self.neighbourhoods[task].weight_vectors[n], task)
            if f2 < f1:
                self.solutions[task][n] = copy.deepcopy(new_solution)
                replacements += 1
                updated.append(n)
            # 判断最大替换次数
            if replacements >= self.max_number_of_replaced_solutions:
                break
        return updated

    def fitness(self, objectives, weight_vector, task):
        max_fun = -1.0e+30
        E = 1.0e-5
        for i in range(len(objectives)):  # 目标函数的个数
            diff = abs(objectives[i] - self.idealPoints[task].get_point()[i] + E)
            if weight_vector[i] == 0:
                feval = diff / 0.000001
            else:
                feval = diff / weight_vector[i]
            # 选取m个目标中 与权重向量乘积的最大值
            if feval > max_fun:
                max_fun = feval
        return max_fun

    def update_progress(self):
        '''写每一次迭代需要做的事情'''
        if self.evaluations % 10000 == 0:
            print(f'当前评估次数{self.evaluations}次', end=', ')
            for i in range(self.problems[0].getNumberOfTasks()):  # 记录IGD和HV指标收敛曲线
                result = get_non_dominated_solutions(self.solutions[i])
                front = check(result)
                igd = InvertedGenerationalDistance(self.problems[i].front)
                igdVal = round(igd.compute([front[j].objectives for j in range(len(front))]), 6)
                hypervolume = HyperVolume([1.0] * self.problems[i].number_of_objectives)
                hvVal = round(hypervolume.compute([front[j].objectives for j in range(len(front))]), 6)
                print(f"IGD_Task{i + 1}: " + str(igdVal), end=', ')
                print(f"HV_Task{i + 1}: " + str(hvVal), end=', ')
            print()

        # 每20代保存一次结果
        period = int(self.termination_criterion.max_evaluations / self.metric_save_times)
        if self.trace_flag:
            if self.evaluations % period == 0:
                for i in range(self.problems[0].getNumberOfTasks()):  # 记录IGD和HV指标收敛曲线
                    result = get_non_dominated_solutions(self.solutions[i])
                    front = check(result)
                    igd = InvertedGenerationalDistance(self.problems[i].front)
                    igdVal = round(igd.compute([front[j].objectives for j in range(len(front))]), 6)
                    hypervolume = HyperVolume([1.0] * self.problems[i].number_of_objectives)
                    hvVal = round(hypervolume.compute([front[j].objectives for j in range(len(front))]), 6)
                    self.trace['IGD'][i].append(igdVal)
                    self.trace['HV'][i].append(hvVal)

        self.evaluations += (2 * self.offspring_population_size)

        if (self.counter == 0) and (self.evaluations % (2 * self.population_size) == 0):
            self.generation += 1
            self.updata_model_values() # 每一次迭代都更新种群高斯分布信息
            self.adaptParas() # 每一次迭代都更新知识类型参数kp

            # 每30代更新一次rmp, 根据动态资源来分配
            if self.generation != 0 and self.generation % 30 == 0:
                self.updateDelta()
                # print(f'{self.generation}---动态更新迁移概率')

        # 更新当前的记录
        observable_data = self.get_observable_data()
        self.observable.notify_all(**observable_data)

    def updateDelta(self):
        for task_idx in range(self.problems[0].getNumberOfTasks()):
            for n in range(self.population_size):
                oldASF = self.fitness(self.lastSolutions[task_idx][n].objectives, self.neighbourhoods[task_idx].weight_vectors[n], task_idx)
                newASF = self.fitness(self.solutions[task_idx][n].objectives, self.neighbourhoods[task_idx].weight_vectors[n], task_idx)
                delta = newASF - oldASF
                if delta > 0.001:
                    self.solutions[task_idx][n].tr = self.tr
                else:
                    utility_value = (0.9 * self.tr + 0.1 * self.tr * delta / 0.0001) * self.solutions[task_idx][n].tr
                    self.solutions[task_idx][n].tr = utility_value if utility_value < self.tr else self.tr
                self.lastSolutions[task_idx][n] = copy.deepcopy(self.solutions[task_idx][n])

    def adaptParas(self):
        for task_idx in range(self.problems[0].getNumberOfTasks()):
            for n in range(self.population_size):
                # offspring[i].tr = np.random.normal(population[t][i].tr, 0.1) # 将生成一组均值约为 0.5，标准差约为 0.1 的随机数
                # offspring[i].tr = min(max(offspring[i].tr, 0), 1)
                self.solutions[task_idx][n].kt = np.random.normal(self.solutions[task_idx][n].kt, 0.1)
                if self.solutions[task_idx][n].kt < 0:
                    self.solutions[task_idx][n].kt = 1 + self.solutions[task_idx][n].kt
                elif self.solutions[task_idx][n].kt > 1:
                    self.solutions[task_idx][n].kt = self.solutions[task_idx][n].kt - 1

                # Parameter mutation
                # if np.random.rand() < self.tau2:
                #     offspring[i].tr = np.random.rand()
                if np.random.rand() < self.tau2:
                    self.solutions[task_idx][n].kt = np.random.rand()

    def get_name(self):
        return 'PROPOSED'

    def get_result(self):
        return self.solutions

    @property
    def label(self) -> str:
        return f'{self.get_name()}.{self.problems[0].get_name()}'


